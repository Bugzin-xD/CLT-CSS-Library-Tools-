# CLT (CSS Library Tools)

Uma biblioteca CSS e JavaScript leve, focada em produtividade, simplicidade e personalização.

---

# Sobre

A CLT (CSS Library Tools) foi criada para acelerar o desenvolvimento front-end utilizando HTML, CSS e JavaScript nativos.

Em vez de substituir a forma tradicional de criar interfaces, a CLT automatiza tarefas repetitivas, mantendo seu código limpo, organizado e fácil de personalizar.

A biblioteca combina CSS moderno, JavaScript leve e recursos nativos do navegador para criar interfaces responsivas com poucas linhas de código.

---

# Recursos

* **Sistema de Temas:** Totalmente baseado em CSS Variables.
* **Componentes Prontos:** Elementos estruturais e visuais prontos para uso.
* **Funções JavaScript Inteligentes:** Automatização nativa sem necessidade de código repetitivo.
* **Floating Labels Automáticas:** Geradas automaticamente através do atributo `clt`.
* **Reveal de Senha:** Sistema integrado para mostrar e ocultar senhas.
* **Estados de Botões:** Suporte para estados ativo, desativado e carregando.
* **Alertas Automáticos:** Elementos personalizados `<clt-alert>` prontos para uso.
* **Helpers Utilitários:** Funções integradas para copiar textos e realizar downloads.
* **Layouts Responsivos:** Containers e componentes estruturais flexíveis.
* **Scrollbar Personalizada:** Barra de rolagem estilizada com visual minimalista.
* **Animações ao Rolar:** Elementos são revelados suavemente conforme entram na tela.
* **Zero Dependências:** Construída inteiramente com HTML, CSS e JavaScript nativos.

---

# Instalação

## Instalação Local

Inclua os arquivos da biblioteca no seu projeto.

```html
<link rel="stylesheet" href="clt-dark-minimalist.css">
<link rel="stylesheet" href="clt.min.css">

<script src="clt-functions.js"></script>
```

---

## Uso Público (CDN)

Você também pode utilizar a CLT diretamente pela versão hospedada, sem precisar baixar nenhum arquivo.

```html
<link rel="stylesheet" href="https://clt-iota.vercel.app/clt-dark-minimalist.css">
<link rel="stylesheet" href="https://clt-iota.vercel.app/clt.min.css">

<script src="https://clt-iota.vercel.app/clt-functions.js"></script>
```

Essa é a forma recomendada para protótipos rápidos e projetos pequenos.

---

# Componentes

## Card

```html
<div class="clt-card">
    <h2 class="clt-card-title">
        Título do Card
    </h2>

    <p class="clt-card-text">
        Texto do card.
    </p>

    <button class="clt-card-button">
        Botão
    </button>
</div>
```

---

## Tipografia & Links

### Título

```html
<h1 class="clt-title">
    Hello World
</h1>
```

### Parágrafo

```html
<p class="clt-p">
    Meu texto.
</p>
```

### Link

```html
<a href="#" class="clt-link">
    Link
</a>
```

---

## Inputs & Formulários

### Input Inteligente

Basta utilizar o atributo `clt`.

```html
<input clt="Nome">
```

A CLT cria automaticamente:

* Floating Label
* Input Group
* Placeholder
* Layout responsivo

### Reveal de Senha

```html
<input
type="password"
clt="Senha"
reveal>
```

Adicionar o atributo `reveal` cria automaticamente um controle para mostrar e ocultar a senha.

---

## Botões & Estados

### Normal

```html
<button class="clt-card-button">
    Botão
</button>
```

### Ativado

```html
<button class="clt-card-button" clt="on">
    Botão
</button>
```

### Desativado

```html
<button class="clt-card-button" clt="off">
    Botão
</button>
```

### Carregando

```html
<button class="clt-card-button" clt="loading">
    Carregando...
</button>
```

---

## Alertas

### Padrão

```html
<clt-alert>
    Mensagem
</clt-alert>
```

### Aviso

```html
<clt-alert type="warn">
    Mensagem
</clt-alert>
```

### Erro

```html
<clt-alert type="alert">
    Mensagem
</clt-alert>
```

---

## Loader

```html
<div class="clt-loader"></div>
```

---

# Helpers JavaScript

A CLT oferece funções JavaScript integradas para eliminar tarefas repetitivas e manter o HTML limpo.

---

## Copiar para a Área de Transferência

Copie automaticamente o conteúdo de qualquer elemento utilizando seu ID.

```html
<pre id="codigo">
Hello World
</pre>

<button
class="clt-card-button"
clt-copy="codigo">
    Copiar
</button>
```

Ao clicar, a CLT copia automaticamente o conteúdo do elemento para a área de transferência.

---

## Download de Arquivos

Realize downloads sem escrever JavaScript.

```html
<button
class="clt-card-button"
clt-download="clt-v1.0.zip">
    Download
</button>
```

Também é possível definir um nome personalizado para o arquivo baixado.

```html
<button
class="clt-card-button"
clt-download="downloads/biblioteca.zip"
download-name="CLT.zip">
    Download
</button>
```

---

# Componentes de Layout

## Header

```html
<header class="clt-header"></header>
```

---

## Navbar

```html
<nav class="clt-navbar"></nav>
```

---

## Main

```html
<main class="clt-main"></main>
```

---

## Section

```html
<section class="clt-section"></section>
```

---

## Container

```html
<div class="clt-container"></div>
```

---

## Centralização

```html
<div class="clt-center"></div>
```

ou

```html
<div class="clt-flex-center"></div>
```

---

## Footer

```html
<footer class="clt-footer">
    <p class="clt-footer-text">
        Footer
    </p>

    <p class="clt-footer-right">
        Loaden TI
    </p>
</footer>
```

---

# Animação ao Rolar a Página

Adicione a classe ao elemento `<body>`.

```html
<body class="clt-animation-scroll">
```

Todos os elementos filhos diretos serão animados suavemente ao entrarem na área visível da tela.

---

# Personalização

A CLT é totalmente baseada em CSS Variables.

Você pode sobrescrever qualquer variável dentro do seu próprio `:root`, sem modificar os arquivos da biblioteca.

Exemplo:

```css
:root{
    --clt-surface:#202020;
    --clt-text:#ffffff;
    --clt-border-color:#00aaff;
}
```

Isso permite personalizar completamente o tema da biblioteca, mantendo futuras atualizações simples.

---

# Boilerplate

Um template HTML pronto para iniciar novos projetos com a CLT.

```html
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Projeto CLT</title>

    <link rel="stylesheet" href="clt-dark-minimalist.css">
    <link rel="stylesheet" href="clt.min.css">
</head>

<body class="clt-animation-scroll">

    <nav class="clt-navbar">
        <h1 class="clt-title">Meu App</h1>
    </nav>

    <main class="clt-main">

        <div class="clt-container clt-flex-center">

            <div class="clt-card">

                <h2 class="clt-card-title">
                    Bem-vindo
                </h2>

                <p class="clt-card-text">
                    Comece a construir sua interface.
                </p>

                <input clt="E-mail">

                <input
                type="password"
                clt="Senha"
                reveal>

                <button class="clt-card-button">
                    Começar
                </button>

            </div>

        </div>

    </main>

    <footer class="clt-footer">
        <p class="clt-footer-text">
            © 2026 Meu Projeto
        </p>

        <p class="clt-footer-right">
            Desenvolvido com CLT
        </p>
    </footer>

    <script src="clt-functions.js"></script>

</body>
</html>
```

---

# Download

## Website

```text
https://clt-iota.vercel.app
```

---

## Repositório no GitHub

```text
https://github.com/Bugzin-xD/CLT-CSS-Library-Tools-
```

---

# Filosofia

A CLT foi desenvolvida seguindo quatro princípios fundamentais:

* **Simplicidade:** Código limpo, leve e fácil de compreender.
* **Performance:** Alto desempenho utilizando apenas tecnologias nativas.
* **Integração Nativa:** Trabalha com HTML, CSS e JavaScript, sem substituir a forma tradicional de desenvolvimento.
* **Personalização:** Controle total sobre a aparência através de CSS Variables.

A proposta da CLT não é criar um novo framework ou uma nova forma de escrever HTML.

Seu objetivo é eliminar tarefas repetitivas, automatizar pequenas funcionalidades e fornecer componentes reutilizáveis, permitindo que o desenvolvedor continue utilizando as tecnologias nativas da Web.

A biblioteca auxilia o desenvolvimento, mas não desenvolve por você.

---

# Compatibilidade

A CLT utiliza apenas recursos modernos do HTML, CSS e JavaScript.

Navegadores recomendados:

* Google Chrome
* Microsoft Edge
* Mozilla Firefox
* Opera
* Brave

Embora possa funcionar em outros navegadores modernos, recomenda-se utilizar versões atualizadas para garantir compatibilidade com todos os recursos da biblioteca.

---

# Estrutura do Projeto

A estrutura padrão da biblioteca é organizada da seguinte forma:

```text
CLT/
├── clt-dark-minimalist.css
├── clt.min.css
├── clt-functions.js
├── README.md
├── README-pt_BR.md
├── CHANGELOG.md
├── LICENSE
└── examples/
```

Essa organização facilita futuras atualizações e mantém a biblioteca simples de utilizar.

---

# Versionamento

A CLT segue o padrão de versionamento semântico (Semantic Versioning).

Exemplo:

```text
v1.0.0
│ │ └── Correções de bugs
│ └──── Novos recursos compatíveis
└────── Grandes mudanças
```

* **Patch:** Correções de bugs e pequenos ajustes.
* **Minor:** Novos recursos sem quebrar compatibilidade.
* **Major:** Mudanças que podem exigir adaptações no código existente.

---

# Contribuição

A CLT é um projeto da **Loaden TI**.

Caso encontre algum problema ou tenha sugestões de melhoria, sinta-se à vontade para abrir uma *Issue* ou enviar um *Pull Request* no repositório oficial.

Todo feedback é bem-vindo e ajuda a biblioteca a evoluir.

---

# Licença

Copyright © Loaden TI.

Todos os direitos reservados.

A redistribuição da biblioteca é permitida desde que os créditos originais sejam mantidos.

A utilização da CLT em projetos pessoais, educacionais ou comerciais é permitida, respeitando os termos definidos pela licença oficial.

---

# CLT v1.0

Obrigado por utilizar a **CLT (CSS Library Tools)**.

Esperamos que ela torne o desenvolvimento das suas interfaces mais rápido, organizado e agradável.

Desenvolvido pela **Loaden TI**.